"""
    Database module
"""

# Modules XBMC
import xbmc

# Modules Custom
from . import jsonrpc
from .log import log
from .url_util import UrlUtil

SORTTITLE = {"method": "sorttitle", "order": "ascending"}
ARTWORK_TYPE_THUMB = "thumb"
ARTWORK_TYPE_POSTER = "poster"
ARTWORK_TYPE_FANART = "fanart"
ARTWORK_TYPE_LOGO = "clearlogo"
ARTWORK_TYPE_CLEARART = "clearart"
ARTWORK_TYPE_BANNER = "banner"
DATABASE_VERSION_FRODO = "75"

# Video database class performing fetching and updating operations
class Database:

    def __init__(self):
        self.json_api = jsonrpc.jsonrpcAPI()

    def getMovieSets(self):
        json = self.json_api.VideoLibrary.GetMovieSets(properties=["art"])
        movie_sets = json.get("sets", [])
        log("Sets: %s" % movie_sets)
        return movie_sets

    def getMoviesInSet(self, setId):
        # Get the list of movies using GetMovieSetDetails
        json = self.json_api.VideoLibrary.GetMovieSetDetails(setid=setId, properties=["art"])
        set_details = json.get("setdetails", [])
        log("Set details: %s" % set_details)
        movies = set_details.get("movies", [])
        for movie in movies:
            # Get the file location of the movie using GetMovieDetails
            json = self.json_api.VideoLibrary.GetMovieDetails(movieid=movie["movieid"], properties=["file", "art"])
            details = json.get("moviedetails", [])
            # log( "Set Movie: %s" % details )
            movie["title"] = movie["label"]
            movie["file"] = details["file"]
        return movies

    # Method to update the URL assigned for movie set artwork in the video DB
    def updateDatabase(self, setId, filename, art_type, force_write):
        # Check what type is already set
        json = self.json_api.VideoLibrary.GetMovieSetDetails(setid=setId, properties=["art"])
        set_details = json.get("setdetails", [])
        set_art = set_details["art"]

        filename = UrlUtil.denormalise(filename, True)

        updated = 0
        if art_type in set_art:
            existing_filename = set_art[art_type]
            log("Existing %s: %s" % (art_type, existing_filename))
            if force_write or (existing_filename.lower() != filename.lower()):
                log("Updating artwork:\nType: %s\nExisting: %s\nNew:      %s" % (art_type, existing_filename, filename),
                    xbmc.LOGDEBUG)
                self.json_api.VideoLibrary.SetMovieSetDetails(setid=setId, art={art_type: filename})
                updated += 1
        else:
            log("Adding artwork:\nType: %s\nFile: %s" % (art_type, filename), xbmc.LOGDEBUG)
            self.json_api.VideoLibrary.SetMovieSetDetails(setid=setId, art={art_type: filename})
            updated += 1
        return updated
