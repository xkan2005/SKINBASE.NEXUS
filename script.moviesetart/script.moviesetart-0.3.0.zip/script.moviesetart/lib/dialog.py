# -*- coding: utf-8 -*-

import xbmcaddon
import xbmcgui

__addon__ = xbmcaddon.Addon("script.moviesetart")
__language__ = __addon__.getLocalizedString
__scriptname__ = __addon__.getAddonInfo('name')

dialog = xbmcgui.DialogProgress()


def dialog_msg(action,
               percent=0,
               heading='',
               line1='',
               line2='',
               line3='',
               nolabel=__language__(32005),
               yeslabel=__language__(32004)):
    # Dialog logic
    if not heading == '':
        heading = heading
    else:
        heading = __scriptname__
    if not line1:
        line1 = ""
    if not line2:
        line2 = ""
    else:
        line2 = "\n" + line2
    if not line3:
        line3 = ""
    else:
        line3 = "\n" + line3
    message = line1 + line2 + line3

    if action == 'create':
        dialog.create(heading, message)
    if action == 'update':
        dialog.update(percent, message)
    if action == 'close':
        dialog.close()
    if action == 'iscanceled':
        if dialog.iscanceled():
            return True
        else:
            return False
    if action == 'okdialog':
        xbmcgui.Dialog().ok(heading, message)
    if action == 'yesno':
        return xbmcgui.Dialog().yesno(heading, message, nolabel, yeslabel)
